package kvraft

import (
	"bytes"
	"fmt"
	"log"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/nihuo9/raft"
	"github.com/nihuo9/raft/labgob"
	"github.com/nihuo9/raft/labrpc"
)


const DebugEx = -1

const (
	MINIMUM_SNAPSHOT_INTERVAL = 500
	MINIMUM_SNAPSHOT_QUANTITY = 100
)

func (kv *KVServer)DPrintlnEx(layer int, a ...interface{}) (n int, err error) {
	if DebugEx >= 0 && layer >= DebugEx {
		pc, _, _, _ := runtime.Caller(1)
		f := runtime.FuncForPC(pc)
		sl := strings.Split(f.Name(), ".")
		fmt.Println("In ", sl[len(sl) - 1], " - ", " server:", kv.me, a)
	}
	return
}

const (
	OP_GET = iota
	OP_PUT
	OP_APPEND
)

type Op struct {
	Meth	int
	Key		string
	Value	string
	UID		uint64
	Seq		uint64
}

type KVServer struct {
	mu      sync.Mutex
	me      int
	rf      *raft.Raft
	applyCh chan raft.ApplyMsg
	dead    int32 // set by Kill()

	maxraftstate int // snapshot if log grows this big

	waits	map[uint64]*waitInfo
	db		map[string]string
	snapVersion int
	lastSnapshotTime time.Time
	lastSnapshotIndex int
	excuted map[uint64]uint64
	persister *raft.Persister
}

func (kv *KVServer) getSnapShot() []byte {
	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	kv.mu.Lock()
	if err := e.Encode(kv.db); err != nil {
		log.Fatal("encode error, err:", err)
	}
	if err := e.Encode(kv.excuted); err != nil {
		log.Fatal("encode error, err:", err)
	}
	kv.mu.Unlock()
	return w.Bytes()
}

func (kv *KVServer) applySnapShot(data []byte) {
	reader := bytes.NewReader(data)
	decoder := labgob.NewDecoder(reader)

	kv.mu.Lock()
	defer kv.mu.Unlock()
	kv.db = make(map[string]string)
	if err := decoder.Decode(&kv.db); err != nil {
		log.Fatal(err)
	}
	if err := decoder.Decode(&kv.excuted); err != nil {
		log.Fatal(err)
	}
}

func (kv *KVServer) applyEntry(msg *raft.ApplyMsg) {
	if msg.CommandValid {
		op := msg.Command.(Op)
		uid := op.UID
		seq := op.Seq
		kv.mu.Lock()
		if old, ok := kv.excuted[uid]; !ok || seq > old {
			// kv.DPrintlnEx(3, "uid:", uid, "seq:", seq, "excuting")
			switch op.Meth {
			case OP_GET:
			case OP_PUT:
				kv.db[op.Key] = op.Value
				// kv.DPrintlnEx(3, "put, key:", op.Key, ",val:", op.Value)
			case OP_APPEND:
				// kv.DPrintlnEx(3, "append, key:", op.Key, ",old-val:", kv.db[op.Key])
				kv.db[op.Key] += op.Value
				// kv.DPrintlnEx(3, "append, key:", op.Key, ",val:", kv.db[op.Key])
			}
			kv.excuted[uid] = seq
			if w, ok := kv.waits[uid]; ok && seq == w.ws{
				delete(kv.waits, uid)
				kv.mu.Unlock()
				close(w.wc)
				kv.checkSize(msg)
				return
			} 
		} else {
			// kv.DPrintlnEx(3, "uid:", op.UID, "seq:", op.Seq, "excuted")
		}
		kv.mu.Unlock()
		kv.checkSize(msg)
	}
}

func (kv *KVServer) checkSize(lastMsg *raft.ApplyMsg) (ok bool, err error){
	if lastMsg.IsSnapShot {
		return false, nil
	}
	if kv.maxraftstate != -1 && kv.persister.RaftStateSize() >= kv.maxraftstate &&// {
		lastMsg.LogIndex - kv.lastSnapshotIndex > MINIMUM_SNAPSHOT_QUANTITY {
		ss := kv.getSnapShot()
		kv.lastSnapshotTime = time.Now()
		// kv.DPrintlnEx(4, "saveSnapshot:", lastMsg.LogIndex)
		kv.rf.SaveStateAndSnapshot(ss, lastMsg.LogIndex)
		return true, nil
	}
	return false, nil
}

func (kv *KVServer) receiveMsg() {
	for m := range kv.applyCh {
		if m.IsSnapShot && (m.CommandIndex > kv.snapVersion || m.CommandIndex == 0) {
			kv.snapVersion = m.CommandIndex
			ss := m.Command.([]byte)
			kv.applySnapShot(ss)
		} else {
			kv.applyEntry(&m)
		}
	}
}

type waitInfo struct {
	wc chan bool
	ws uint64
}

func (kv *KVServer) Get(args *GetArgs, reply *GetReply) {
	kv.mu.Lock()

	if args.Seq < kv.excuted[args.UID] {
		reply.Code = ErrSequence
		kv.mu.Unlock()
		return
	} else if args.Seq == kv.excuted[args.UID] {
		if val, ok := kv.db[args.Key]; ok {
			reply.Value = val
			reply.Code = OK
			// kv.DPrintlnEx(2, "1-get:", args.Key, ",val:", val)
		} else {
			reply.Code = ErrNoKey
		}
		kv.mu.Unlock()
		return
	}
	// kv.DPrintlnEx(3, "Get:", args.UID, "seq:", args.Seq, "get:", args.Key)
	kv.waits[args.UID] = &waitInfo{ wc: make(chan bool), ws: args.Seq }
	wc := kv.waits[args.UID].wc
	kv.mu.Unlock()

	op := Op{
		Meth: OP_GET,
		Key: args.Key,
		UID: args.UID,
		Seq: args.Seq,
	}
	_, _, ok := kv.rf.Start(op)
	if !ok {
		reply.Code = ErrWrongLeader
		return
	}

	if wc != nil {
		select {
		case <-wc:
			kv.mu.Lock()
			if val, ok := kv.db[args.Key]; ok {
				reply.Code = OK
				reply.Value = val
				// kv.DPrintlnEx(2, "2-get:", args.Key,",val:", val)
			} else {
				reply.Code = ErrNoKey
			}
			kv.mu.Unlock()
		case <-time.After(3 * time.Second):
			kv.mu.Lock()
			delete(kv.waits, op.UID)
			kv.mu.Unlock()
			reply.Code = ErrTimeout
		}
	}
}

func (kv *KVServer) PutAppend(args *PutAppendArgs, reply *PutAppendReply) {
	kv.mu.Lock()
	if args.Seq < kv.excuted[args.UID] {
		reply.Code = ErrSequence
		kv.mu.Unlock()
		return
	} else if args.Seq == kv.excuted[args.UID] {
		/*
		if args.Op == "Append" {
			kv.DPrintlnEx(2, "1-key:", args.Key, "Append:", args.Value)
		} else {
			kv.DPrintlnEx(2, "1-key:", args.Key, "Put:", args.Value)
		}
		*/
		reply.Code = OK
		kv.mu.Unlock()
		return
	}
	//kv.DPrintlnEx(3, "putappend:", args.UID, "seq:", args.Seq, "key:", args.Key, "val:", args.Value)
	kv.waits[args.UID] = &waitInfo{ wc: make(chan bool), ws: args.Seq }
	wc := kv.waits[args.UID].wc
	kv.mu.Unlock()

	op := Op{
		Key: args.Key,
		Value: args.Value,
		UID: args.UID,
		Seq: args.Seq,
	}
	if args.Op == "Put" {
		op.Meth = OP_PUT
	} else if args.Op == "Append" {
		op.Meth = OP_APPEND
	}
	_, _, ok := kv.rf.Start(op)
	if !ok {
		reply.Code = ErrWrongLeader
		return
	}
	
	if wc != nil {
		select {
		case <-wc:
			reply.Code = OK
			/*
			if args.Op == "Append" {
				kv.DPrintlnEx(2, "2-key:", args.Key, "Append:", args.Value)
			} else {
				kv.DPrintlnEx(2, "2-key:", args.Key, "Put:", args.Value)
			}
			*/
		case <-time.After(3 * time.Second):
			kv.mu.Lock()
			delete(kv.waits, op.UID)
			kv.mu.Unlock()
			reply.Code = ErrTimeout
		}
	}
}

//
// the tester calls Kill() when a KVServer instance won't
// be needed again. for your convenience, we supply
// code to set rf.dead (without needing a lock),
// and a killed() method to test rf.dead in
// long-running loops. you can also add your own
// code to Kill(). you're not required to do anything
// about this, but it may be convenient (for example)
// to suppress debug output from a Kill()ed instance.
//
func (kv *KVServer) Kill() {
	atomic.StoreInt32(&kv.dead, 1)
	kv.rf.Kill()
}

func (kv *KVServer) killed() bool {
	z := atomic.LoadInt32(&kv.dead)
	return z == 1
}

//
// servers[] contains the ports of the set of
// servers that will cooperate via Raft to
// form the fault-tolerant key/value service.
// me is the index of the current server in servers[].
// the k/v server should store snapshots through the underlying Raft
// implementation, which should call persister.SaveStateAndSnapshot() to
// atomically save the Raft state along with the snapshot.
// the k/v server should snapshot when Raft's saved state exceeds maxraftstate bytes,
// in order to allow Raft to garbage-collect its log. if maxraftstate is -1,
// you don't need to snapshot.
// StartKVServer() must return quickly, so it should start goroutines
// for any long-running work.
//
func StartKVServer(servers []*labrpc.ClientEnd, me int, persister *raft.Persister, maxraftstate int) *KVServer {
	// call labgob.Register on structures you want
	// Go's RPC library to marshall/unmarshall.
	labgob.Register(Op{})

	kv := new(KVServer)
	kv.me = me
	kv.maxraftstate = maxraftstate

	kv.excuted = make(map[uint64]uint64)
	kv.db = make(map[string]string)
	kv.applyCh = make(chan raft.ApplyMsg)
	go kv.receiveMsg()
	kv.rf = raft.Make(servers, me, persister, kv.applyCh)
	kv.persister = persister

	kv.waits = make(map[uint64]*waitInfo)

	return kv
}
