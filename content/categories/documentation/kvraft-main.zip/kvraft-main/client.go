package kvraft

import (
	"crypto/rand"
	"fmt"
	"math/big"

	"github.com/nihuo9/raft/labrpc"
)

var _DEBUG int = -1

func DPrintln(layer int, args ...interface{}) (n int, err error) {
	if _DEBUG >= 0 && layer >= _DEBUG {
		return fmt.Println(args...)
	}

	return 0, nil
}

type Clerk struct {
	servers []*labrpc.ClientEnd
	curLeader int
	id	uint64
	seq	uint64
}

func nrand() int64 {
	max := big.NewInt(int64(1) << 62)
	bigx, _ := rand.Int(rand.Reader, max)
	x := bigx.Int64()
	return x
}

func MakeClerk(servers []*labrpc.ClientEnd) *Clerk {
	ck := new(Clerk)
	ck.servers = servers
	ck.curLeader = 0
	ck.id = uint64(nrand())
	ck.seq = 1
	return ck
}

//
// fetch the current value for a key.
// returns "" if the key does not exist.
// keeps trying forever in the face of all other errors.
//
func (ck *Clerk) Get(key string) string {
	arg := GetArgs{
		Key: key,
		UID: ck.id,
		Seq: ck.seq,
	}
	reply := GetReply{}

	for {
		ok := ck.servers[ck.curLeader].Call("KVServer.Get", &arg, &reply)
		if ok {
			if reply.Code == OK {
				ck.seq++
				return reply.Value
			} else if reply.Code == ErrNoKey {
				ck.seq++
				return ""
			}
		}
		/*
		if reply.Code == ErrDuplicateUID {
			ck.id = uint64(nrand())
			arg.UID = ck.id
		} else {
		*/
			ck.curLeader++
			if ck.curLeader == len(ck.servers) {
				ck.curLeader = 0
			}
		//}
		// DPrintln(1, "get err:", reply.Code, ",uid:", arg.UID, ",seq:", arg.Seq, ",curleader:", ck.curLeader, "key:", key)
	}
}

//
// shared by Put and Append.
//
func (ck *Clerk) PutAppend(key string, value string, op string) {
	arg := PutAppendArgs{
		Key: key,
		Value: value,
		Op: op,
		UID: ck.id,
		Seq: ck.seq,
	}
	reply := PutAppendReply{}

	// DPrintln(1, "put start ,uid:", arg.UID, ",seq:", arg.Seq, "key:", key, "val:", value)
	for {
		ok := ck.servers[ck.curLeader].Call("KVServer.PutAppend", &arg, &reply)
		if ok && reply.Code == OK {
			ck.seq++
			break
		}

		/*if reply.Code == ErrDuplicateUID {
			ck.id = uint64(nrand())
			arg.UID = ck.id
		} else {
		*/
			ck.curLeader++
			if ck.curLeader == len(ck.servers) {
				ck.curLeader = 0
			}
		//}

		// DPrintln(1, "put err:", reply.Code, ",uid:", arg.UID, ",seq:", arg.Seq, ",curleader:", ck.curLeader, "key:", key, "val:", value)
	}
	// DPrintln(1, "put end ,uid:", arg.UID, ",seq:", arg.Seq, "key:", key, "val:", value)
}

func (ck *Clerk) Put(key string, value string) {
	ck.PutAppend(key, value, "Put")
}
func (ck *Clerk) Append(key string, value string) {
	ck.PutAppend(key, value, "Append")
}
