package kvraft

//type Err string
const (
	OK             	= "OK"
	ErrNoKey       	= "ErrNoKey"
	ErrWrongLeader 	= "ErrWrongLeader"
	ErrMethod	   	= "ErrMethod"
	ErrTimeout	   	= "ErrTimeout"
	ErrDuplicateUID	= "ErrDuplicateUID"
	ErrSequence		= "ErrSequence"
	ErrNil		   	= "ErrNil"
)

// Put or Append
type PutAppendArgs struct {
	Key   string
	Value string
	Op    string // "Put" or "Append"
	UID		uint64
	Seq		uint64
}

type PutAppendReply struct {
	Code 	string
//	Seq		uint64
}

type GetArgs struct {
	Key 	string
	UID		uint64
	Seq		uint64
}

type GetReply struct {
	Code   	string
	Value 	string
//	Seq		uint64
}