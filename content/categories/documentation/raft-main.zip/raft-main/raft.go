package raft

//
// this is an outline of the API that raft must expose to
// the service (or tester). see comments below for
// each of these functions for more details.
//
// rf = Make(...)
//   create a new Raft server.
// rf.Start(command interface{}) (index, term, isleader)
//   start agreement on a new log entry
// rf.GetState() (term, isLeader)
//   ask a Raft for its current term, and whether it thinks it is leader
// ApplyMsg
//   each time a new entry is committed to the log, each Raft peer
//   should send an ApplyMsg to the service (or tester)
//   in the same server.
//

import (
	"bytes"
	"log"
	"math"
	"math/rand"
	"sort"
	"sync"
	"sync/atomic"
	"time"

	"github.com/nihuo9/raft/labgob"
	"github.com/nihuo9/raft/labrpc"

	"fmt"
	"runtime"
	"strings"
)

var _DEBUGEX = -1

const (
	TIMEOUT_MIN            = 1000
	TIMEOUT_MAX            = 1100
	TIMEOUT_CALL           = 950
	HEARTBEAT_TIME         = 150
	MINIMUM_RETRY_INTERVAL = 150
	SLEEP_TIME             = 10
)

const (
	STATE_CANDIDATE = iota
	STATE_LEADER
	STATE_FOLLOWER
	STATE_EXIT
)

const (
	WAIT_NULL = iota
	WAIT_APPEND
	WAIT_HEARTBEAT
	WAIT_SNAP
	WAIT_VOTE
	WAIT_LEN
)

//
// as each Raft peer becomes aware that successive log entries are
// committed, the peer should send an ApplyMsg to the service (or
// tester) on the same server, via the applyCh passed to Make(). set
// CommandValid to true to indicate that the ApplyMsg contains a newly
// committed log entry.
type ApplyMsg struct {
	CommandValid bool
	Command      interface{}
	CommandIndex int
	IsSnapShot   bool
	LogIndex     int
}

type Entry struct {
	Command ApplyMsg
	Term    int
}

type Snapshot struct {
	LastIncludeIndex        int
	LastIncludeTerm         int
	LastIncludeCommandIndex int
}

//
// A Go object implementing a single Raft peer.
//
type Raft struct {
	mu        sync.Mutex          // Lock to protect shared access to this peer's state
	peers     []*labrpc.ClientEnd // RPC end points of all peers
	persister *Persister          // Object to hold this peer's persisted state
	me        int                 // this peer's index into peers[]
	dead      int32               // set by Kill()

	tc *time.Ticker
	state     int
	done      chan struct{}
	applyCh   chan ApplyMsg
	available map[int]bool
	connectTime  time.Time
	nCheckCommit int

	// persistent
	currentTerm int
	votedFor    int
	log         []*Entry
	snapshot    Snapshot

	// volatile
	commitIndex int
	lastApplied int

	// leader
	nextIndex  []int
	matchIndex []int

	// candidate
	votes int
	// follower
}

func randTicker() *time.Ticker {
	timeout := time.Millisecond * time.Duration((rand.Int()%(TIMEOUT_MAX-TIMEOUT_MIN) + TIMEOUT_MIN))
	ticker := time.NewTicker(timeout)
	return ticker
}

func resetRand(ticker *time.Ticker) {
	ticker.Reset(time.Millisecond * time.Duration((rand.Int()%(TIMEOUT_MAX-TIMEOUT_MIN) + TIMEOUT_MIN)))
}

func (rf *Raft) PrintlnEx(layer int, a ...interface{}) (n int, err error) {
	///*
	if _DEBUGEX >= 0 && layer >= _DEBUGEX {
		pc, _, _, _ := runtime.Caller(1)
		f := runtime.FuncForPC(pc)
		sl := strings.Split(f.Name(), ".")
		var state string
		if rf.state == STATE_CANDIDATE {
			state = "candidate"
		} else if rf.state == STATE_FOLLOWER {
			state = "follower"
		} else {
			state = "leader"
		}
		return fmt.Println("Now:", time.Now().Format("15:04:05.000"), "In", sl[len(sl)-1], "-", "server:", rf.me, ",term:", rf.currentTerm, ",state:", state, ",", a)
	}
	//*/
	return 0, nil
}

// return currentTerm and whether this server
// believes it is the leader.
func (rf *Raft) GetState() (int, bool) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	return rf.currentTerm, rf.state == STATE_LEADER
}

// for persister
func (rf *Raft) getRaftState() []byte {
	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	e.Encode(rf.currentTerm)
	e.Encode(rf.votedFor)
	e.Encode(rf.log)

	return w.Bytes()
}

//
// save Raft's persistent state to stable storage,
// where it can later be retrieved after a crash and restart.
// see paper's Figure 2 for a description of what should be persistent.
//
func (rf *Raft) persist() {
	data := rf.getRaftState()
	rf.persister.SaveRaftState(data)
}

//
// restore previously persisted state.
//
func (rf *Raft) readPersist(data []byte) {
	if data == nil || len(data) < 1 { // bootstrap without any state?
		return
	}
	r := bytes.NewBuffer(data)
	d := labgob.NewDecoder(r)
	var currentTerm int
	var voteFor int
	var lo []*Entry

	if err := d.Decode(&currentTerm); err != nil {
		log.Fatalf("Decode error, %v", err)
	}
	if err := d.Decode(&voteFor); err != nil {
		log.Fatalf("Decode error, %v", err)
	}
	if err := d.Decode(&lo); err != nil {
		log.Fatalf("Decode error, %v", err)
	}
	rf.currentTerm = currentTerm
	rf.votedFor = voteFor
	rf.log = lo
}

func (rf *Raft) excute(ent *Entry) bool {
	if ent.Command.CommandValid {
		rf.applyCh <- ent.Command
		return true
	}
	return false
}

func (rf *Raft) tryApply() bool {
	rf.mu.Lock()
	if rf.commitIndex > rf.lastApplied {

		entry := rf.log[rf.realIndex(rf.lastApplied+1)]
		rf.lastApplied++
		rf.mu.Unlock()
		rf.excute(entry)
		return true
	}
	rf.mu.Unlock()
	return false
}

// The actual index in the log
func (rf *Raft) realIndex(index int) int {
	return index - rf.snapshot.LastIncludeIndex
}

func (rf *Raft) logIndex(index int) int {
	return index + rf.snapshot.LastIncludeIndex
}

func (rf *Raft) saveStateAndSnapshot(sm []byte, lastIncludeIndex int) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	lastIncludeIndex = rf.realIndex(lastIncludeIndex)
	if lastIncludeIndex <= 0 || lastIncludeIndex >= len(rf.log) {
		return
	}
	rf.snapshot.LastIncludeTerm = rf.log[lastIncludeIndex].Term
	rf.snapshot.LastIncludeCommandIndex = rf.log[lastIncludeIndex].Command.CommandIndex
	rf.log = append(rf.log[0:1], rf.log[lastIncludeIndex+1:]...)
	rf.snapshot.LastIncludeIndex = rf.logIndex(lastIncludeIndex)

	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	e.Encode(rf.snapshot)
	e.Encode(sm)
	rf.persister.SaveStateAndSnapshot(rf.getRaftState(), w.Bytes())
}

// sm is state machine
func (rf *Raft) SaveStateAndSnapshot(sm []byte, lastIncludeIndex int) {
	//rf.PrintlnEx(2, "SaveSnapshot, lastIncludeIndex:", lastIncludeIndex)
	rf.saveStateAndSnapshot(sm, lastIncludeIndex)
}

func (rf *Raft) readSnapshot(ss []byte) (*Snapshot, []byte) {
	if ss == nil || len(ss) < 1 {
		return nil, nil
	}

	r := bytes.NewBuffer(ss)
	d := labgob.NewDecoder(r)

	var (
		snapshot Snapshot
		sm       []byte
	)

	if err := d.Decode(&snapshot); err != nil {
		log.Fatalf("Decode snapshot error: %v", err)
	}
	if err := d.Decode(&sm); err != nil {
		log.Fatalf("Decode state machine error: %v", err)
	}

	return &snapshot, sm
}

//***************************************** Leader ***************************************************//
type AppendEntriesArgs struct {
	Term         int
	LeaderID     int
	PrevLogIndex int
	PrevLogTerm  int
	Entries      []*Entry
	LeaderCommit int
}

//
type AppendEntriesReply struct {
	Term    int
	Success bool
	XTerm   int
	XIndex  int
}

type InstallSnapshotArgs struct {
	Term             int
	LeaderID         int
	LastIncludeIndex int
	LastIncludeTerm  int
	Offset           int
	Data             []byte
	Done             bool
}

type InstallSnapshotReply struct {
	Term int
}

func (rf *Raft) InstallSnapshot(args *InstallSnapshotArgs, reply *InstallSnapshotReply) {
	ss, sm := rf.readSnapshot(args.Data)
	rf.mu.Lock()
	rf.available[args.LeaderID] = true
	reply.Term = rf.currentTerm
	if args.Term < rf.currentTerm {
		rf.mu.Unlock()
		return
	} else if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		rf.votedFor = -1
	}

	li := rf.realIndex(args.LastIncludeIndex)
	if li > 0 && li < len(rf.log) && rf.log[li].Term == args.LastIncludeTerm {
		rf.log = append(rf.log[0:1], rf.log[li+1:]...)
	} else {
		rf.log = rf.log[0:1]
	}
	rf.snapshot = *ss
	rf.lastApplied = ss.LastIncludeIndex
	rf.commitIndex = ss.LastIncludeIndex
	snapMsg := ApplyMsg{IsSnapShot: true, Command: sm, CommandIndex: rf.log[0].Command.CommandIndex + 1}
	rf.log[0].Command.CommandIndex++
	//rf.PrintlnEx(31, "snap ver-1:", rf.log[0].Command.CommandIndex)
	rf.persister.SaveStateAndSnapshot(rf.getRaftState(), args.Data)

	rf.connectTime = time.Now()
	if rf.state != STATE_FOLLOWER {
		rf.state = STATE_FOLLOWER
	}
	rf.mu.Unlock()
	rf.applyCh <- snapMsg
}

func (rf *Raft) callInstallSnapshot(server int, args *InstallSnapshotArgs, reply *InstallSnapshotReply) chan bool {
	var res bool
	peer := rf.peers[server]
	rc := make(chan bool)
	done := make(chan struct{})

	// Transition from synchronous call to asynchronous
	go func() {
		res = peer.Call("Raft.InstallSnapshot", args, reply)
		done <- struct{}{}
	}()

	go func() {
		select {
		case <-done:
			rc <- res
		case <-time.After(time.Millisecond * TIMEOUT_CALL):
			rc <- false
			<-done
		}
	}()

	return rc
}

//
//
func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	var bPersist = false
	rf.mu.Lock()
	defer func() {
		if bPersist {
			rf.persist()
		}
		rf.mu.Unlock()
	}()

	rf.available[args.LeaderID] = true

	reply.Term = rf.currentTerm
	if args.Term < rf.currentTerm {
		return
	} else if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		rf.votedFor = -1
		bPersist = true
	}

	// reset connectTime to prevent the follower becoming a candidate
	rf.connectTime = time.Now()
	if rf.state != STATE_FOLLOWER {
		rf.state = STATE_FOLLOWER
	}

	// Check whether the logs match
	args.PrevLogIndex = rf.realIndex(args.PrevLogIndex)
	if args.PrevLogIndex == 0 {
		if args.PrevLogTerm != rf.snapshot.LastIncludeTerm {
			log.Fatal("The entry was committed but have a different term?")
			return
		}
	} else {
		if args.PrevLogIndex >= len(rf.log) || args.PrevLogIndex < 0 || rf.log[args.PrevLogIndex].Term != args.PrevLogTerm {
			if args.PrevLogIndex > len(rf.log) {
				args.PrevLogIndex = len(rf.log)
			}
			for i := args.PrevLogIndex - 1; i >= 0; i-- {
				if rf.log[i].Term <= args.PrevLogTerm {
					reply.XIndex = rf.logIndex(i)
					if i > 0 {
						reply.XTerm = rf.log[i].Term
					} else {
						reply.XTerm = rf.snapshot.LastIncludeTerm
					}
					break
				}
			}
			return
		}
	}

	reply.Success = true
	if len(args.Entries) > 0 {
		bPersist = true
		start := args.PrevLogIndex + 1
		for i := 0; i < len(args.Entries); i++ {
			// This step is to see which logs are inconsistent or have exceeded the log index
			if start+i >= len(rf.log) || (args.Entries[i].Term != rf.log[start+i].Term) {
				// rf.PrintlnEx(81, "recv entry, start:", start+i, ",add:", len(args.Entries)-i, ",leader:", args.LeaderID)
				rf.log = append(rf.log[:start+i], args.Entries[i:]...)
				break
			}
		}
	} else {
		// rf.PrintlnEx(81, "recv heartbeat, from", args.LeaderID, ",prev:", args.PrevLogIndex)
	}

	if args.LeaderCommit > rf.commitIndex {
		commitIndex := int(math.Min(float64(args.LeaderCommit), float64(rf.logIndex(len(rf.log)-1))))
		// rf.PrintlnEx(61, "commitIndex:", commitIndex)
		rf.commitIndex = commitIndex
	}
}

func (rf *Raft) callAppendEntries(server int, args *AppendEntriesArgs, reply *AppendEntriesReply) chan bool {
	var res bool
	peer := rf.peers[server]
	rc := make(chan bool)
	done := make(chan bool)

	go func() {
		res = peer.Call("Raft.AppendEntries", args, reply)
		done <- res
	}()

	go func() {
		select {
		case <-done:
			rc <- res
		case <-time.After(time.Millisecond * TIMEOUT_CALL):
			rc <- false
			<-done
		}
	}()

	return rc
}

type callAppendEntriesResult struct {
	rsp  AppendEntriesReply
	ok   bool
	id   int
	q    int
	seq  int
	isHb bool
}

type callInstallSnapshotResult struct {
	rsp  InstallSnapshotReply
	last int
	id   int
	seq  int
	ok   bool
}

func (rf *Raft) sendHeartbeat(server, seq int, resc chan<- *callAppendEntriesResult) {
	var rsp = callAppendEntriesResult{
		id:   server,
		isHb: true,
		seq:  seq,
	}

	// rf.PrintlnEx(81, "send heartbeat to", server, ",cur commit:", rf.commitIndex, ",cur log len:", len(rf.log))
	args := AppendEntriesArgs{
		LeaderID: rf.me,
		Term:     rf.currentTerm,
	}

	args.LeaderCommit = rf.commitIndex
	args.PrevLogIndex = rf.nextIndex[server] - 1

	if args.PrevLogIndex >= rf.snapshot.LastIncludeIndex {
		if args.PrevLogIndex > rf.snapshot.LastIncludeIndex {
			args.PrevLogTerm = rf.log[rf.realIndex(rf.nextIndex[server]-1)].Term
		} else {
			args.PrevLogTerm = rf.snapshot.LastIncludeTerm
		}

		ok := rf.callAppendEntries(server, &args, &rsp.rsp)

		go func() {
			rsp.ok = <-ok
			resc <- &rsp
		}()
	} else {
		log.Fatal("PrevLogIndex < lastIncludeIndex ?")
	}
}

func (rf *Raft) sendAppendEntries(server, seq int, resc chan<- *callAppendEntriesResult) {
	var rsp = callAppendEntriesResult{
		id:   server,
		isHb: false,
		seq:  seq,
	}

	args := AppendEntriesArgs{
		LeaderID: rf.me,
		Term:     rf.currentTerm,
	}

	args.LeaderCommit = rf.commitIndex
	args.PrevLogIndex = rf.nextIndex[server] - 1

	if args.PrevLogIndex >= rf.snapshot.LastIncludeIndex {
		index := rf.realIndex(rf.nextIndex[server] - 1)
		if index > 0 {
			args.PrevLogTerm = rf.log[index].Term
		} else {
			args.PrevLogTerm = rf.snapshot.LastIncludeTerm
		}
		args.Entries = make([]*Entry, len(rf.log[index + 1:]))
		copy(args.Entries, rf.log[index + 1:])
		rsp.q = len(rf.log) - index - 1
		// rf.PrintlnEx(81, "send appendentries to", server, "prev:", args.PrevLogIndex)
		ok := rf.callAppendEntries(server, &args, &rsp.rsp)

		go func() {
			rsp.ok = <-ok
			resc <- &rsp
		}()
	} else {
		log.Fatal("PrevLogIndex < lastIncludeIndex ?")
	}
}

func (rf *Raft) sendSnapshot(server, seq int, resc chan<- *callInstallSnapshotResult) {
	var rsp = callInstallSnapshotResult{
		id:   server,
		seq:  seq,
		last: rf.snapshot.LastIncludeIndex,
	}

	// rf.PrintlnEx(81, "send Snapshot to", server)
	args := InstallSnapshotArgs{
		Term:             rf.currentTerm,
		LeaderID:         rf.me,
		LastIncludeIndex: rf.snapshot.LastIncludeIndex,
		LastIncludeTerm:  rf.snapshot.LastIncludeTerm,
		Offset:           0,
		Data:             rf.persister.ReadSnapshot(),
		Done:             true,
	}

	ok := rf.callInstallSnapshot(server, &args, &rsp.rsp)

	go func() {
		rsp.ok = <-ok
		resc <- &rsp
	}()
}

func (rf *Raft) tackleAppendEntriesResult(res *callAppendEntriesResult) int {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	if rf.state != STATE_LEADER {
		return rf.state
	}
	if res.ok {
		id := res.id
		rf.available[id] = true
		if res.rsp.Success {
			// rf.PrintlnEx(81, "recv from:", res.id, ",num:", res.q)
			if !res.isHb {
				rf.matchIndex[id] = rf.nextIndex[id] + res.q - 1
				rf.nextIndex[id] = rf.matchIndex[id] + 1
				rf.nCheckCommit++
			} else {
				if rf.matchIndex[id] < rf.nextIndex[id]-1 {
					rf.matchIndex[id] = rf.nextIndex[id] - 1
					rf.nCheckCommit++
				}
			}
		} else {
			// rf.PrintlnEx(81, "recv from:", res.id, ",fail")
			if res.rsp.Term > rf.currentTerm {
				rf.currentTerm = res.rsp.Term
				rf.votedFor = -1
				rf.persist()
				if rf.state != STATE_FOLLOWER {
					rf.state = STATE_FOLLOWER
					return STATE_FOLLOWER
				}
			}

			id := res.id
			var i int
			for i = res.rsp.XIndex; i > 0; i-- {
				if rf.realIndex(i) <= 0 || rf.log[rf.realIndex(i)].Term <= res.rsp.XTerm {
					break
				}
			}
			rf.nextIndex[id] = i + 1
		}

		if len(rf.available) > len(rf.peers)/2 {
			rf.connectTime = time.Now()
		}
	} else {
		// rf.PrintlnEx(81, "timeout:", res.id)
		delete(rf.available, res.id)
		if len(rf.available) <= len(rf.peers)/2 {
			if time.Since(rf.connectTime) > TIMEOUT_MIN {
				// rf.PrintlnEx(81, "lost majority connect:")
				rf.state = STATE_FOLLOWER
				return STATE_FOLLOWER
			}
		}
	}
	return STATE_LEADER
}

func (rf *Raft) tackleInstallSnapshotResult(res *callInstallSnapshotResult) int {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	if rf.state != STATE_LEADER {
		return rf.state
	}
	if res.ok {
		// rf.PrintlnEx(81, "send snapshot ack from", res.id)
		rf.available[res.id] = true
		if res.rsp.Term > rf.currentTerm {
			rf.currentTerm = res.rsp.Term
			rf.votedFor = -1
			rf.persist()
			if rf.state != STATE_FOLLOWER {
				rf.state = STATE_FOLLOWER
				return STATE_FOLLOWER
			}
		}

		id := res.id
		rf.matchIndex[id] = res.last
		rf.nextIndex[id] = rf.logIndex(len(rf.log))

		if len(rf.available) > len(rf.peers)/2 {
			rf.connectTime = time.Now()
		}
	} else {
		// rf.PrintlnEx(81, "send snap timeout:", res.id)
		delete(rf.available, res.id)
		if len(rf.available) <= len(rf.peers)/2 {
			if time.Since(rf.connectTime) > TIMEOUT_MIN {
				// rf.PrintlnEx(81, "lost majority connect:")
				rf.state = STATE_FOLLOWER
				return STATE_FOLLOWER
			}
		}
	}
	return STATE_LEADER
}

func (rf *Raft) calCommit() bool {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	news := make([]int, len(rf.matchIndex))
	copy(news, rf.matchIndex)
	sort.Ints(news)
	for i := len(news) / 2; i >= 0; i-- {
		if news[i] > rf.commitIndex {
			if rf.log[rf.realIndex(news[i])].Term != rf.currentTerm && i != 0 {
				continue
			}
			// rf.PrintlnEx(81, "commit-old:", rf.commitIndex, ",new:", news[i])
			rf.commitIndex = news[i]
			return true
		}
	}
	return false
}

type waitInfo struct {
	typ   int
	times [WAIT_LEN]int
	seqs  [WAIT_LEN]int
}

func (rf *Raft) convertLeader() int {
	rf.mu.Lock()
	if rf.state != STATE_LEADER {
		defer rf.mu.Unlock()
		return rf.state
	}
	for i := 0; i < len(rf.nextIndex); i++ {
		rf.nextIndex[i] = rf.logIndex(len(rf.log))
	}
	for i := 0; i < len(rf.matchIndex); i++ {
		rf.matchIndex[i] = 0
	}
	rf.matchIndex[rf.me] = rf.logIndex(len(rf.log) - 1)
	rf.nCheckCommit = 1
	rf.connectTime = time.Now()
	// insert no-op
	rf.insertEntry(&Entry{
		Term: rf.currentTerm,
		Command: ApplyMsg{
			CommandValid: false,
		},
	})
	rf.mu.Unlock()

	var sendTimes = make([]time.Time, len(rf.peers))
	var waits = make([]waitInfo, len(rf.peers))
	var appendEntriesResC = make(chan *callAppendEntriesResult)
	var snapshotResC = make(chan *callInstallSnapshotResult)
	var seq = 1

	defer func() {
		go func() {
			for _, w := range waits {
				for i := 0; i < w.times[WAIT_APPEND]+w.times[WAIT_HEARTBEAT]; i++ {
					<-appendEntriesResC
				}
				for i := 0; i < w.times[WAIT_SNAP]; i++ {
					<-snapshotResC
				}
			}
		}()
	}()

	for {
		select {
		case rsp := <-appendEntriesResC:
			needTackle := false
			if rsp.isHb {
				waits[rsp.id].times[WAIT_HEARTBEAT]--
				if waits[rsp.id].typ == WAIT_HEARTBEAT &&
					rsp.seq > waits[rsp.id].seqs[WAIT_HEARTBEAT] {
					waits[rsp.id].seqs[WAIT_HEARTBEAT] = rsp.seq
					needTackle = true
				}
			} else {
				waits[rsp.id].times[WAIT_APPEND]--
				if waits[rsp.id].typ == WAIT_APPEND &&
					rsp.seq > waits[rsp.id].seqs[WAIT_APPEND] {
					waits[rsp.id].seqs[WAIT_APPEND] = rsp.seq
					needTackle = true
				}
			}
			if needTackle {
				waits[rsp.id].typ = WAIT_NULL
				seq++
				state := rf.tackleAppendEntriesResult(rsp)
				if state != STATE_LEADER {
					return state
				}
			}
		case rsp := <-snapshotResC:
			waits[rsp.id].times[WAIT_SNAP]--
			if waits[rsp.id].typ == WAIT_SNAP &&
				rsp.seq > waits[rsp.id].seqs[WAIT_SNAP] {
				waits[rsp.id].seqs[WAIT_SNAP] = rsp.seq
				waits[rsp.id].typ = WAIT_NULL
				seq++
				state := rf.tackleInstallSnapshotResult(rsp)
				if state != STATE_LEADER {
					return state
				}
			}
		case <-rf.done:
			return STATE_EXIT
		default:
			rf.mu.Lock()
			if rf.state != STATE_LEADER {
				defer rf.mu.Unlock()
				return rf.state
			}
			for i := 0; i < len(waits); i++ {
				if i == rf.me {
					continue
				}
				if waits[i].typ == WAIT_NULL || time.Since(sendTimes[i]) > MINIMUM_RETRY_INTERVAL*time.Millisecond {
					if rf.nextIndex[i] <= rf.snapshot.LastIncludeIndex {
						sendTimes[i] = time.Now()
						waits[i].typ = WAIT_SNAP
						waits[i].times[WAIT_SNAP]++
						rf.sendSnapshot(i, seq, snapshotResC)
					} else if rf.realIndex(rf.nextIndex[i]) < len(rf.log) {
						sendTimes[i] = time.Now()
						waits[i].typ = WAIT_APPEND
						waits[i].times[WAIT_APPEND]++
						rf.sendAppendEntries(i, seq, appendEntriesResC)
					}
					if waits[i].typ == WAIT_NULL && time.Since(sendTimes[i]) > HEARTBEAT_TIME*time.Millisecond {
						sendTimes[i] = time.Now()
						waits[i].typ = WAIT_HEARTBEAT
						waits[i].times[WAIT_HEARTBEAT]++
						rf.sendHeartbeat(i, seq, appendEntriesResC)
					}
				}
			}
			rf.mu.Unlock()

			if rf.nCheckCommit > 0 {
				rf.calCommit()
				rf.nCheckCommit = 0
			}

			if !rf.tryApply() {
				time.Sleep(time.Millisecond * SLEEP_TIME)
			}
		}
	}
}

//*************************************************************************************************//

//************************************************* Candidate **************************************//
type RequestVoteArgs struct {
	Term         int
	CandidateID  int
	LastLogIndex int
	LastLogTerm  int
}

type RequestVoteReply struct {
	Term        int
	VoteGranted bool
	VoteFor     int
}

func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	reply.VoteGranted = false
	var bPersist = false
	rf.mu.Lock()
	defer func() {
		if bPersist {
			rf.persist()
		}
		rf.mu.Unlock()
	}()
	rf.available[args.CandidateID] = true
	reply.Term = rf.currentTerm
	reply.VoteFor = rf.votedFor

	if time.Since(rf.connectTime) < TIMEOUT_MIN*time.Millisecond {
		return
	}

	// convert to follower if the term of args is bigger than current term
	if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		bPersist = true
		rf.votedFor = -1
		if rf.state != STATE_FOLLOWER {
			rf.state = STATE_FOLLOWER
		}
	}

	// refuse the request if the term of args is smaller than current term or itself has voted
	if args.Term < rf.currentTerm || rf.votedFor >= 0 {
		//rf.Println("req.term:", args.Term)
		return
	}

	//	Determine whether the log is "up-to-date".
	//  If the logs havelast entries with differentterms, then
	//	the log with the later term is more up-to-date. If the logs
	//	end with the same term, then whichever log is longer is
	//	more up-to-date.
	lastIndex := rf.logIndex(len(rf.log))
	var lastTerm int = rf.log[len(rf.log)-1].Term
	if lastIndex == rf.snapshot.LastIncludeIndex+1 {
		lastTerm = rf.snapshot.LastIncludeTerm
	}
	/*rf.Println("my last-term:", rf.log[nLog - 1].Term, "my last-index:", nLog, ",req:",args.CandidateID, ",req last-term:",
	args.LastLogTerm, ",req last-index:", args.LastLogIndex)*/
	if lastTerm > args.LastLogTerm ||
		(lastTerm == args.LastLogTerm && lastIndex > args.LastLogIndex+1) {
		return
	}

	// rf.PrintlnEx(81, "me:", rf.me, ",votefor:", args.CandidateID, "args.term:", args.Term)
	reply.VoteGranted = true
	rf.votedFor = args.CandidateID
	rf.connectTime = time.Now()
	bPersist = true
	if rf.state != STATE_FOLLOWER {
		rf.state = STATE_FOLLOWER
	}
}

func (rf *Raft) callRequestVote(server int, args *RequestVoteArgs, reply *RequestVoteReply) chan bool {
	var res bool
	peer := rf.peers[server]
	rc := make(chan bool)
	done := make(chan struct{})

	go func() {
		res = peer.Call("Raft.RequestVote", args, reply)
		done <- struct{}{}
	}()

	go func() {
		select {
		case <-done:
			rc <- res
		case <-time.After(time.Millisecond * TIMEOUT_CALL):
			rc <- false
			<-done
		}
	}()

	return rc
}

type callRequestVoteResult struct {
	id  int
	rsp RequestVoteReply
	ok  bool
}

func (rf *Raft) sendRequestVote(server int, resc chan<- *callRequestVoteResult) {
	var rsp = callRequestVoteResult{
		id: server,
	}
	// rf.PrintlnEx(81, "sendRequestVote to", server)
	args := RequestVoteArgs{
		CandidateID: rf.me,
	}

	nLog := len(rf.log)
	args.LastLogIndex = rf.logIndex(nLog - 1)
	if args.LastLogIndex == rf.snapshot.LastIncludeIndex {
		args.LastLogTerm = rf.snapshot.LastIncludeTerm
	} else {
		args.LastLogTerm = rf.log[nLog-1].Term
	}
	args.Term = rf.currentTerm

	ok := rf.callRequestVote(server, &args, &rsp.rsp)

	go func() {
		rsp.ok = <-ok
		resc <- &rsp
	}()
}

func (rf *Raft) tackleRequestVoteResult(res *callRequestVoteResult) int {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	if rf.state != STATE_CANDIDATE {
		return rf.state
	}
	if res.ok {
		rf.available[res.id] = true
		if res.rsp.VoteGranted || res.rsp.VoteFor == rf.me {
			rf.votes++
			// rf.PrintlnEx(81, "rec vote: ", res.id)
			// If more than half of the votes are received, the server is switched to the lead
			if rf.votes > (len(rf.peers) / 2) {
				if rf.state != STATE_LEADER {
					rf.state = STATE_LEADER
					return STATE_LEADER
				}
			}
		} else if res.rsp.Term > rf.currentTerm {
			// rf.PrintlnEx(81, "vote less term: ", res.id)
			rf.currentTerm = res.rsp.Term
			rf.votedFor = -1
			rf.persist()
			if rf.state != STATE_FOLLOWER {
				rf.state = STATE_FOLLOWER
				return STATE_FOLLOWER
			}
		}
	} else {
		// rf.PrintlnEx(81, "vote, timeout:", res.id)
		delete(rf.available, res.id)
		/* if len(rf.available) <= len(rf.peers)/2 {
			rf.state = STATE_FOLLOWER
			return STATE_FOLLOWER
		}*/
	}
	return STATE_CANDIDATE
}

func (rf *Raft) convertCandidate() int {
	var waits = make([]waitInfo, len(rf.peers))
	var sendTimes = make([]time.Time, len(rf.peers))
	var requestVoteResC = make(chan *callRequestVoteResult)
	var remain = len(rf.peers) - 1

	defer func() {
		go func() {
			for _, w := range waits {
				for i := 0; i < w.times[WAIT_VOTE]; i++ {
					<-requestVoteResC
				}
			}
		}()
	}()

	resetRand(rf.tc)
	rf.mu.Lock()
	//rf.PrintlnEx(1, "state:Candidate")
	if rf.state == STATE_CANDIDATE {
		rf.currentTerm++
		rf.votedFor = rf.me
		rf.votes = 1
		rf.persist()

		for i := 0; i < len(rf.peers); i++ {
			if i == rf.me {
				continue
			}
			waits[i].typ = WAIT_VOTE
			waits[i].times[WAIT_VOTE] = 1
			sendTimes[i] = time.Now()
			rf.sendRequestVote(i, requestVoteResC)
		}
		rf.mu.Unlock()
	} else {
		defer rf.mu.Unlock()
		return rf.state
	}

	for {
		select {
		case rsp := <-requestVoteResC:
			waits[rsp.id].times[WAIT_VOTE]--
			if waits[rsp.id].typ == WAIT_VOTE {
				remain--
				waits[rsp.id].typ = WAIT_NULL
				state := rf.tackleRequestVoteResult(rsp)
				if state != STATE_CANDIDATE {
					return state
				}
			}
		case <-rf.tc.C:
			return STATE_CANDIDATE
		case <-rf.done:
			return STATE_EXIT
		default:
			rf.mu.Lock()
			if rf.state != STATE_CANDIDATE {
				defer rf.mu.Unlock()
				return rf.state
			}
			if remain + rf.votes > len(rf.peers) / 2 {
				for i := 0; i < len(rf.peers); i++ {
					if i == rf.me {
						continue
					}
					if waits[i].typ == WAIT_VOTE &&
						time.Since(sendTimes[i]) > MINIMUM_RETRY_INTERVAL * time.Millisecond {
						// retry
						waits[i].times[WAIT_VOTE]++
						sendTimes[i] = time.Now()
						rf.sendRequestVote(i, requestVoteResC)
					}
				}
			}
			rf.mu.Unlock()

			if !rf.tryApply() {
				time.Sleep(time.Millisecond * SLEEP_TIME)
			}
		}
	}
}

//***************************************** Follower ***************************************************//
func (rf *Raft) convertFollower() int {
	for {
		select {
		case <-rf.tc.C:
			rf.mu.Lock()
			if time.Since(rf.connectTime) > TIMEOUT_MIN*time.Millisecond {
				rf.state = STATE_CANDIDATE
				rf.mu.Unlock()
				return STATE_CANDIDATE
			}
			rf.mu.Unlock()
		case <-rf.done:
			return STATE_EXIT
		default:
			if !rf.tryApply() {
				time.Sleep(time.Millisecond * SLEEP_TIME)
			}
		}
	}
}

//*************************************************************************************************//
func (rf *Raft) Run() {
	state := STATE_FOLLOWER
	for {
		if state == STATE_FOLLOWER {
			state = rf.convertFollower()
		} else if state == STATE_CANDIDATE {
			state = rf.convertCandidate()
		} else if state == STATE_LEADER {
			state = rf.convertLeader()
		} else {
			break
		}
	}
	rf.tc.Stop()
}

func (rf *Raft) insertEntry(entry *Entry) int {
	index := len(rf.log) - 1

	if index == 0 {
		if entry.Command.CommandValid {
			entry.Command.CommandIndex = rf.snapshot.LastIncludeCommandIndex
		} else {
			entry.Command.CommandIndex = rf.snapshot.LastIncludeCommandIndex
		}
	} else {
		if entry.Command.CommandValid {
			entry.Command.CommandIndex = rf.log[index].Command.CommandIndex + 1
		} else {
			entry.Command.CommandIndex = rf.log[index].Command.CommandIndex
		}
	}
	rf.log = append(rf.log, entry)
	entry.Command.LogIndex = rf.logIndex(index + 1)
	rf.matchIndex[rf.me] = rf.logIndex(index + 1)
	rf.persist()

	//rf.PrintlnEx(1, "command index:", entry.Command.CommandIndex)
	return entry.Command.CommandIndex
}

//
// the service using Raft (e.g. a k/v server) wants to start
// agreement on the next command to be appended to Raft's log. if this
// server isn't the leader, returns false. otherwise start the
// agreement and return immediately. there is no guarantee that this
// command will ever be committed to the Raft log, since the leader
// may fail or lose an election. even if the Raft instance has been killed,
// this function should return gracefully.
//
// the first return value is the index that the command will appear at
// if it's ever committed. the second return value is the current
// term. the third return value is true if this server believes it is
// the leader.
//
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	if rf.state != STATE_LEADER {
		return -1, -1, false
	}

	/*
	if _, ok := command.(int); ok {
		rf.PrintlnEx(81, "recv command:", command.(int))
	} else {
		rf.PrintlnEx(81, "recv command:")
	}
	*/

	entry := Entry{
		Command: ApplyMsg{
			Command:      command,
			CommandValid: true,
		},
		Term: rf.currentTerm,
	}
	index := rf.insertEntry(&entry)

	return index, rf.currentTerm, true
}

//
// the tester doesn't halt goroutines created by Raft after each test,
// but it does call the Kill() method. your code can use killed() to
// check whether Kill() has been called. the use of atomic avoids the
// need for a lock.
//
// the issue is that long-running goroutines use memory and may chew
// up CPU time, perhaps causing later tests to fail and generating
// confusing debug output. any goroutine with a long-running loop
// should call killed() to check whether it should stop.
//
func (rf *Raft) Kill() {
	atomic.StoreInt32(&rf.dead, 1)
	close(rf.done)
}

func (rf *Raft) killed() bool {
	z := atomic.LoadInt32(&rf.dead)
	return z == 1
}

//
// the service or tester wants to create a Raft server. the ports
// of all the Raft servers (including this one) are in peers[]. this
// server's port is peers[me]. all the servers' peers[] arrays
// have the same order. persister is a place for this server to
// save its persistent state, and also initially holds the most
// recent saved state, if any. applyCh is a channel on which the
// tester or service expects Raft to send ApplyMsg messages.
// Make() must return quickly, so it should start goroutines
// for any long-running work.
//
func Make(peers []*labrpc.ClientEnd, me int,
	persister *Persister, applyCh chan ApplyMsg) *Raft {
	rf := &Raft{}
	rf.peers = peers
	rf.persister = persister
	rf.me = me
	rf.tc = randTicker()
	rf.state = STATE_FOLLOWER
	rf.done = make(chan struct{})
	rf.currentTerm = 0
	rf.votedFor = -1
	rf.log = []*Entry{{}}
	rf.commitIndex = 0
	rf.lastApplied = 0
	rf.nextIndex = make([]int, len(rf.peers))
	rf.matchIndex = make([]int, len(rf.peers))
	rf.applyCh = applyCh
	rf.available = make(map[int]bool)

	for i := 0; i < len(rf.peers); i++ {
		rf.available[i] = true
	}

	// initialize from state persisted before a crash
	rf.readPersist(persister.ReadRaftState())
	ss, sm := rf.readSnapshot(persister.ReadSnapshot())
	if ss != nil {
		rf.snapshot = *ss
		rf.lastApplied = ss.LastIncludeIndex
		rf.applyCh <- ApplyMsg{IsSnapShot: true, Command: sm, CommandIndex: rf.log[0].Command.CommandIndex}
	}

	go rf.Run()

	return rf
}
